package test.coinchange.domain.impl;

public abstract class AbstractAtm {

	
	
}
