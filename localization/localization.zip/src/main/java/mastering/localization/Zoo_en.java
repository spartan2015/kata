package mastering.localization;

import java.util.ListResourceBundle;

class Zoo_en extends ListResourceBundle {
	protected Object[][] getContents() {
		return new Object[][] { { "greeting", "Good Day !" } };
	}
}
