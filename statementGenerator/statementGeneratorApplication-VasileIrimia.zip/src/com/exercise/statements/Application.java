package com.exercise.statements;

import com.exercise.statements.model.Action;
import com.exercise.statements.model.NamedObject;
import com.exercise.statements.model.Person;
import com.exercise.statements.model.Thing;

import java.util.Arrays;
import java.util.List;

public class Application {
    public static void main(String[] args) {
        Person p1 = new Person("p1");
        Action a1 = new Action("a1");
        Thing t1 = new Thing("t1");
        List<List<NamedObject>> result = StatementsGenerator.produceStatements(
                Arrays.asList(p1, a1, t1),
                Rules.getRules(), 5, 1);
        StatementsPrinter.print(result);
    }
}
