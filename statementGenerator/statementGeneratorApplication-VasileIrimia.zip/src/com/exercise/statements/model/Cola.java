package com.exercise.statements.model;

public class Cola extends Thing implements Drinkable {

    public Cola(String name) {
        super(name);
    }
}
