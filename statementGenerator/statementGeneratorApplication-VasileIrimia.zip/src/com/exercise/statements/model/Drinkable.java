package com.exercise.statements.model;

public interface Drinkable {

}
