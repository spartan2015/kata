package com.exercise.statements.model;

public class NamedObject {
    private  String name;

    public NamedObject(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
