package com.exercise.statements.model;

public class Person extends NamedObject {
    public Person(String name) {
        super(name);
    }
}
