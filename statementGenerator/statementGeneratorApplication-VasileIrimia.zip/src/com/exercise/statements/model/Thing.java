package com.exercise.statements.model;

public class Thing extends NamedObject {

    public Thing(String name) {
        super(name);
    }
}
